# Java Mini Project – Console-based Quiz App

## 📘 Description
This is a simple Java console quiz app developed as part of the Java Developer Internship. It demonstrates:
- Loops and control structures
- Object-Oriented Programming (OOP)
- Collections like `ArrayList`

## 🚀 How to Run
1. Compile both files:
   ```
   javac Question.java QuizApp.java
   ```
2. Run the main app:
   ```
   java QuizApp
   ```

## 🛠 Technologies Used
- Java
- Console (Terminal)

## 📄 Output
Interactive multiple-choice quiz with score at the end.