import java.util.*;

public class QuizApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Question> questions = new ArrayList<>();

        questions.add(new Question("What are Java loops?", new String[]{
            "Control structures", "Data types", "Classes", "Objects"}, 1));
        questions.add(new Question("What is enhanced for-loop?", new String[]{
            "Old loop", "Iterator class", "Simplified for loop", "While loop"}, 3));
        questions.add(new Question("How do you handle multiple user inputs?", new String[]{
            "BufferedReader", "Scanner with loops", "Only Console class", "None"}, 2));
        questions.add(new Question("How is switch-case different from if-else?", new String[]{
            "Only syntax", "Switch is faster and cleaner", "No difference", "Only used in loops"}, 2));
        questions.add(new Question("What are collections in Java?", new String[]{
            "Group of variables", "Group of classes", "Framework to store & manipulate data", "Set of conditions"}, 3));

        int score = 0;

        for (Question q : questions) {
            q.display();
            System.out.print("Your answer (1-4): ");
            int answer = scanner.nextInt();
            if (q.isCorrect(answer)) {
                System.out.println("✅ Correct!\n");
                score++;
            } else {
                System.out.println("❌ Incorrect. Correct option was: " + q.correctOption + "\n");
            }
        }

        System.out.println("🎯 Your final score: " + score + "/" + questions.size());
        scanner.close();
    }
}